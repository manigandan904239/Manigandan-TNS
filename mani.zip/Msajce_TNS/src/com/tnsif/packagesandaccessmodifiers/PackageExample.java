package com.tnsif.packagesandaccessmodifiers;

public class PackageExample {

	
	public void display() {
		System.out.println("Displaying PackageExample class");
	}
	
}
