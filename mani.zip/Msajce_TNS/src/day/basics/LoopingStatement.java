package day.basics;

public class LoopingStatement {

}
