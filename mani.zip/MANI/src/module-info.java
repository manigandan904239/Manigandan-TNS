/**
 * 
 */
/**
 * 
 */
module MANI {
}