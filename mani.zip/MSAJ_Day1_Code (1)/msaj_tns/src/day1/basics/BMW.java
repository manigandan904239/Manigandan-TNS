package day1.basics;

public class BMW {
	
	void show() {
		System.out.println("Hii");
	}
	
	
	public static void main(String[] args) {
		BMW obj = new BMW();
		obj.show();
	}

}

 