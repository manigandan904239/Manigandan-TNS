package com.manigandan.assignment2;

public class Maincircle {
 public static void main(String[] args) {
        Circle c = new Circle();
        c.getInput();
        c.calcArea();
    }
}

