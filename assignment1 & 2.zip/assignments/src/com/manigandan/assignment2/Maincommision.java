package com.manigandan.assignment2;

public class Maincommision {

    @SuppressWarnings("unused")
	public static void main(String[] args) {
        Student s = new Student();
        Commission c = new Commission();
        c.acceptDetails();
        c.calculateCommission();
    }
}
